This folder contains all the info for each repair.

The program pulls from these files to display the info in the program, so do not remove, rename or move any of these files. Otherwise the program won't be able to display the info of the repair. It won't interfere with the repair itself, it just won't be able to show any information on what the repair does.

Also these files will be overwritten when you update, so making changes to these files isn't needed.
